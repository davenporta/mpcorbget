mpcorbget v1.0.0a3
=======================

This is a tool for planning observations of minor planets. It pulls data from the Minor Planet Center's MPCORB.DAT and its list of observatories and calculates the geocentric and topocentric coordinates of the object.

In addition to calculating coordinates, it provides an api to retrieve and utilize data from the MPC for use in other scripts.


